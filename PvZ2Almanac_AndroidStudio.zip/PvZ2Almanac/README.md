# PvZ2 Almanac · Android Studio

Мобильный альманах **Plants vs. Zombies 2** на Kotlin/Jetpack Compose в стиле игрового альманаха (зелёный фон, коричневая рамка, бежевые карточки, вертикальные миниатюры слева). Архитектура повторяет учебные принципы [MoviesDemo](https://github.com/Julia-Mamsheva/MoviesDemo/): SOLID, Clean Architecture, Hilt, `ViewModel` + `StateFlow`, smart/dumb Compose-экраны, тесты логики, ViewModel и UI.

## Запуск

1. Распакуйте проект и откройте **всю папку `PvZ2Almanac`** в Android Studio (`File > Open`). Не открывайте отдельно `app`.
2. Установите Android SDK 35 в **SDK Manager**, выберите **JDK 17** в Gradle settings, подключите интернет для первого Gradle Sync.
3. Дождитесь загрузки зависимостей, запустите конфигурацию `app` на Android 8+ (API 26+).
4. При первом запуске *все названия* из исходного каталога (137 растений, 203 зомби и 12 миров) появятся без интернета; приложение попробует обновить списки через API. Характеристики и изображения запрашиваются **по мере показа элементов** и сохраняются в Room.

Для консоли (Windows): `gradlew.bat assembleDebug`. На Linux/macOS: `./gradlew assembleDebug`.
APK после сборки: `app/build/outputs/apk/debug/app-debug.apk`.

> **Важно**: APK в архиве нет — для сборки Android-приложения необходимы Android SDK и Gradle, которых нет в среде создания этого архива. Исходный код и конфигурация проекта включены, но фактическую Android/Gradle-сборку здесь выполнить не удалось.

## Возможности

- Три вкладки: **растения, зомби, миры**.
- Поиск по названию без учета регистра и сортировка по названию, стоимости солнца (для растений), собственные записи первыми.
- Локальные фильтры: **все**, **добавленные мной**, **отредактированные**, **с характеристиками**, **без характеристик**; выбор поля и одного из значений, которые уже есть в кеше. Фильтры не отправляют запросы на сервер.
- Добавление собственных записей, изменение названия, изображения и любого набора свойств, скрытие серверной записи, удаление своей.
- Локальное хранение в **Room (SQLite)**, сохранение изменений после перезапуска. При обновлении с сервера локальные изменения не перезаписываются.
- Ленивая загрузка деталей только видимых карточек и кеширование результатов (требование fair use API). Изображения скачиваются по URL с помощью Coil (с кешем), при недоступности подставляются пиктограммы.

## Источник данных

Бесплатное API: https://pvz-2-api.vercel.app/docs

`GET /api/plants`, `/api/zombies`, `/api/areas` — списки названий.
`GET /api/{kind}/{name}` — сведения об одной записи, в JSON разные ключи для разных типов.

API **доступно только для чтения**. Изменения из приложения записываются в **локальную Room** и не отправляются на сервер. Публичная база может быть неполной или устаревшей; некоторые карточки могут не иметь доступных деталей/картинок.

`app/src/main/assets/catalog_names.json` — локальный стартовый каталог названий из API. Обновить его можно вручную. При повторном открытии приложение не удаляет добавленные локально записи.

## Архитектура проекта

```
app/src/main/java/com/example/pvz2almanac/
├── domain/                        # чистые Kotlin модели, контракт, бизнес-логика
│   ├── model/CatalogModels.kt
│   ├── repository/CatalogRepository.kt
│   └── usecase/FilterAndSortEntries.kt
├── data/                          # Android-specific источники и реализация контракта
│   ├── remote/PvzApi.kt           # Retrofit, GET
│   ├── local/                     # Room Entity / DAO / Database
│   ├── repository/CatalogRepositoryImpl.kt
│   └── di/DataModule.kt          # Hilt @Binds/@Provides
├── presentation/                  # ViewModel, Compose, состояние экрана
│   ├── vm/AlmanacViewModel.kt
│   └── ui/AlmanacRoute.kt        # smart route: ViewModel
│       ├── AlmanacScreen.kt      # dumb screen: state + callbacks
│       ├── EntryEditorDialog.kt
│       └── PvzTheme.kt
├── PvzApp.kt
└── MainActivity.kt
```

Правило зависимостей: **presentation → domain ← data**. Репозиторий объявлен в domain, реализация находится в data. Пакеты физически внутри одного Gradle модуля (как учебный MoviesDemo), разделены по ответственности. UI не вызывает Room и Retrofit напрямую. `FilterAndSortEntries` не знает про Android.

## Тесты

- `testDebugUnitTest`: `FilterAndSortEntriesTest` — поиск/сортировка/фильтрация, `AlmanacViewModelTest` — состояние UI при поиске с подменой репозитория.
- `connectedDebugAndroidTest`: `AlmanacScreenTest` — Compose UI-тест без реального API и Hilt.

Запуск: `./gradlew testDebugUnitTest` или `./gradlew connectedDebugAndroidTest` (для второго нужен эмулятор/телефон).

## Зависимости / сборка

Kotlin 2.0.21, AGP 8.7.3, Gradle 8.9, Java 17, Hilt 2.52, Room 2.6.1, Retrofit 2.11, Coil 2.7 и Compose BOM 2024.12.01. Версии намеренно немного более консервативные, чем в актуальном MoviesDemo, чтобы поддерживать Android 8+.

В папке `gradle/wrapper/` находится **неофициальный минимальный Gradle bootstrap JAR** с **включённым открытым исходным кодом `Bootstrap.java`**, поскольку официальный Gradle Wrapper JAR недоступен из среды подготовки архива. Он загружает именно Gradle 8.9 с `services.gradle.org`, сверяет официальный SHA-256 и запускает дистрибутив. Для замены стандартным Wrapper после первого запуска: `./gradlew wrapper --gradle-version 8.9`.

## Примечание по изображениям

Игровые картинки **не включены** в архив: изображения запрашиваются из открытого API. Вид альманаха воспроизводит **цвета и компоновку** примера, но не содержит копий игрового интерфейса или платных ресурсов.
