package com.example.pvz2almanac

import androidx.compose.ui.test.assertExists
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performTextInput
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.pvz2almanac.domain.model.AlmanacEntry
import com.example.pvz2almanac.domain.model.Category
import com.example.pvz2almanac.presentation.ui.AlmanacScreen
import com.example.pvz2almanac.presentation.ui.PvzTheme
import com.example.pvz2almanac.presentation.vm.AlmanacUiState
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AlmanacScreenTest {
    @get:Rule val compose = createComposeRule()

    @Test fun `search change is emitted without using ViewModel or network`() {
        var typed = ""
        compose.setContent {
            PvzTheme {
                AlmanacScreen(
                    state = AlmanacUiState(
                        items = listOf(AlmanacEntry("p1", Category.PLANTS, "Aloe")),
                        selected = AlmanacEntry("p1", Category.PLANTS, "Aloe")
                    ),
                    onCategory = {}, onQuery = { typed = it }, onSort = {},
                    onFilter = {}, onAttributeKey = {}, onAttributeValue = {},
                    onSelect = {}, onVisible = {}, onAdd = {}, onEdit = {},
                    onDelete = {}, onRefresh = {}, onDismissMessage = {}
                )
            }
        }
        compose.onNodeWithTag("catalogSearch").assertExists().performTextInput("aloe")
        compose.runOnIdle { assertEquals("aloe", typed) }
    }
}
