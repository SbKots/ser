package com.example.pvz2almanac.domain

import com.example.pvz2almanac.domain.model.AlmanacEntry
import com.example.pvz2almanac.domain.model.CatalogCriteria
import com.example.pvz2almanac.domain.model.Category
import com.example.pvz2almanac.domain.model.EntryFilter
import com.example.pvz2almanac.domain.model.SortMode
import com.example.pvz2almanac.domain.usecase.FilterAndSortEntries
import org.junit.Assert.assertEquals
import org.junit.Test

class FilterAndSortEntriesTest {
    private val useCase = FilterAndSortEntries()
    private val source = listOf(
        AlmanacEntry("a", Category.PLANTS, "Sunflower", attributes = mapOf("Sun cost" to "50", "Family" to "Enlighten-mint")),
        AlmanacEntry("b", Category.PLANTS, "Peashooter", attributes = mapOf("Sun cost" to "100", "Family" to "Appease-mint")),
        AlmanacEntry("c", Category.PLANTS, "Aloe", attributes = mapOf("Sun cost" to "75", "Family" to "Reinforce-mint"), isCustom = true),
        AlmanacEntry("d", Category.ZOMBIES, "Basic zombie", attributes = mapOf("toughness" to "Average")),
        AlmanacEntry("e", Category.PLANTS, "Hidden", isHidden = true)
    )

    @Test fun `search is case insensitive and respects category`() {
        assertEquals(listOf("Peashooter"), useCase(source, CatalogCriteria(query = "SHOOT")).map { it.name })
    }

    @Test fun `sort by sun cost ignores records without price`() {
        assertEquals(listOf("Sunflower", "Aloe", "Peashooter"),
            useCase(source, CatalogCriteria(sort = SortMode.COST_ASC)).map { it.name })
    }

    @Test fun `filter by family and own records`() {
        assertEquals(listOf("Aloe"), useCase(source,
            CatalogCriteria(attributeKey = "Family", attributeValue = "Reinforce-mint")).map { it.name })
        assertEquals(listOf("Aloe"), useCase(source,
            CatalogCriteria(filter = EntryFilter.MY_ENTRIES)).map { it.name })
    }
}
