package com.example.pvz2almanac.presentation

import com.example.pvz2almanac.domain.model.AlmanacEntry
import com.example.pvz2almanac.domain.model.Category
import com.example.pvz2almanac.domain.repository.CatalogRepository
import com.example.pvz2almanac.domain.usecase.FilterAndSortEntries
import com.example.pvz2almanac.presentation.vm.AlmanacViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class AlmanacViewModelTest {
    private val dispatcher = StandardTestDispatcher()

    @Before fun setup() { Dispatchers.setMain(dispatcher) }
    @After fun tearDown() { Dispatchers.resetMain() }

    @Test fun `filter and selection update presentation state`() = runTest(dispatcher) {
        val repo = FakeRepository()
        val vm = AlmanacViewModel(repo, FilterAndSortEntries())
        val job = backgroundScope.launch { vm.state.collect {} }
        advanceUntilIdle()

        assertEquals(2, vm.state.value.items.size)
        vm.setSearch("aloe")
        advanceUntilIdle()
        assertEquals("Aloe", vm.state.value.selected?.name)
        assertEquals(1, vm.state.value.items.size)
        job.cancel()
    }

    private class FakeRepository : CatalogRepository {
        private val items = MutableStateFlow(listOf(
            AlmanacEntry("1", Category.PLANTS, "Aloe"),
            AlmanacEntry("2", Category.PLANTS, "Sunflower")
        ))
        override fun observeEntries(): Flow<List<AlmanacEntry>> = items
        override suspend fun prepareOfflineCatalog() = Unit
        override suspend fun refreshNames(): String? = null
        override suspend fun loadDetailsIfNeeded(id: String) = Unit
        override suspend fun save(entry: AlmanacEntry) {
            items.value = items.value.filterNot { it.id == entry.id } + entry
        }
        override suspend fun remove(id: String) {
            items.value = items.value.filterNot { it.id == id }
        }
    }
}
