package com.example.pvz2almanac

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class PvzApp : Application()
