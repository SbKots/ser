package com.example.pvz2almanac.presentation.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.pvz2almanac.domain.model.AlmanacEntry
import com.example.pvz2almanac.domain.model.Category

private data class EditableField(val name: String = "", val value: String = "")

@Composable
fun EntryEditorDialog(
    category: Category,
    original: AlmanacEntry?,
    onDismiss: () -> Unit,
    onSave: (name: String, imageUrl: String, fields: Map<String, String>) -> Unit
) {
    var name by remember(original?.id) { mutableStateOf(original?.name.orEmpty()) }
    var imageUrl by remember(original?.id) { mutableStateOf(original?.imageUrl.orEmpty()) }
    var error by remember(original?.id) { mutableStateOf(false) }
    val fields = remember(original?.id) {
        mutableStateListOf<EditableField>().apply {
            addAll(original?.attributes?.map { EditableField(it.key, it.value) }.orEmpty())
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Parchment,
        title = { Text(if (original == null) "Добавить: ${category.singular.lowercase()}" else "Редактирование") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it; error = false },
                    label = { Text("Название *") }, singleLine = true,
                    isError = error, modifier = Modifier.fillMaxWidth().testTag("entryName")
                )
                if (error) Text("Название не должно быть пустым", color = androidx.compose.ui.graphics.Color.Red)
                OutlinedTextField(
                    value = imageUrl, onValueChange = { imageUrl = it },
                    label = { Text("Ссылка на изображение (необязательно)") },
                    modifier = Modifier.fillMaxWidth(), maxLines = 2
                )
                Text("Характеристики (сохраняются только на устройстве)")
                fields.forEachIndexed { index, field ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        OutlinedTextField(
                            value = field.name,
                            onValueChange = { fields[index] = field.copy(name = it) },
                            label = { Text("Поле") }, singleLine = true,
                            modifier = Modifier.weight(0.43f)
                        )
                        OutlinedTextField(
                            value = field.value,
                            onValueChange = { fields[index] = field.copy(value = it) },
                            label = { Text("Значение") },
                            modifier = Modifier.weight(0.48f)
                        )
                        IconButton(onClick = { fields.removeAt(index) }) {
                            Icon(Icons.Default.Close, contentDescription = "Удалить поле")
                        }
                    }
                }
                OutlinedButton(onClick = { fields.add(EditableField()) }) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Text("Добавить характеристику", modifier = Modifier.padding(start = 5.dp))
                }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
        confirmButton = {
            Button(onClick = {
                if (name.isBlank()) { error = true; return@Button }
                onSave(name, imageUrl, fields.filter { it.name.isNotBlank() }
                    .associate { it.name.trim() to it.value.trim() })
            }, modifier = Modifier.testTag("saveEntry")) {
                Text("Сохранить")
            }
        }
    )
}
