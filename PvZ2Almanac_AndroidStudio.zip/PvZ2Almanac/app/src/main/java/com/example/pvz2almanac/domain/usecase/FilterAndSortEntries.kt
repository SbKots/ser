package com.example.pvz2almanac.domain.usecase

import com.example.pvz2almanac.domain.model.AlmanacEntry
import com.example.pvz2almanac.domain.model.CatalogCriteria
import com.example.pvz2almanac.domain.model.EntryFilter
import com.example.pvz2almanac.domain.model.SortMode

/** Локальный поиск, сортировки и фильтры — чистый Kotlin, пригоден для unit-тестирования. */
class FilterAndSortEntries {
    operator fun invoke(source: List<AlmanacEntry>, criteria: CatalogCriteria): List<AlmanacEntry> {
        val filtered = source.asSequence()
            .filter { it.category == criteria.category && !it.isHidden }
            .filter { it.name.contains(criteria.query.trim(), ignoreCase = true) }
            .filter { item ->
                when (criteria.filter) {
                    EntryFilter.ALL -> true
                    EntryFilter.MY_ENTRIES -> item.isCustom
                    EntryFilter.EDITED -> item.isEdited
                    EntryFilter.WITH_DETAILS -> item.detailsLoaded && item.attributes.isNotEmpty()
                    EntryFilter.WITHOUT_DETAILS -> !item.detailsLoaded || item.attributes.isEmpty()
                }
            }
            .filter { item ->
                val key = criteria.attributeKey
                val value = criteria.attributeValue
                if (key.isNullOrEmpty() || value.isNullOrEmpty()) true
                else item.attributes.entries.any {
                    it.key.equals(key, ignoreCase = true) && it.value.equals(value, ignoreCase = true)
                }
            }
            .toList()

        return when (criteria.sort) {
            SortMode.NAME_ASC -> filtered.sortedBy { it.name.lowercase() }
            SortMode.NAME_DESC -> filtered.sortedByDescending { it.name.lowercase() }
            SortMode.CUSTOM_FIRST -> filtered.sortedWith(
                compareByDescending<AlmanacEntry> { it.isCustom }.thenBy { it.name.lowercase() }
            )
            SortMode.COST_ASC -> filtered.sortedWith(
                compareBy<AlmanacEntry> { cost(it) == null }
                    .thenBy { cost(it) ?: Int.MAX_VALUE }
                    .thenBy { it.name.lowercase() }
            )
            SortMode.COST_DESC -> filtered.sortedWith(
                compareBy<AlmanacEntry> { cost(it) == null }
                    .thenByDescending { cost(it) ?: Int.MIN_VALUE }
                    .thenBy { it.name.lowercase() }
            )
        }
    }

    private fun cost(item: AlmanacEntry): Int? {
        val value = item.attributes.entries.firstOrNull {
            it.key.equals("Sun cost", true) || it.key.equals("Стоимость", true)
        }?.value ?: return null
        return Regex("\\d+").find(value)?.value?.toIntOrNull()
    }
}
