package com.example.pvz2almanac.presentation.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import coil.compose.SubcomposeAsyncImageContent
import com.example.pvz2almanac.domain.model.AlmanacEntry
import com.example.pvz2almanac.domain.model.Category
import com.example.pvz2almanac.domain.model.EntryFilter
import com.example.pvz2almanac.domain.model.SortMode
import com.example.pvz2almanac.presentation.vm.AlmanacUiState

/** Dumb UI: никаких запросов к API, Room и ViewModel внутри. */
@Composable
fun AlmanacScreen(
    state: AlmanacUiState,
    onCategory: (Category) -> Unit,
    onQuery: (String) -> Unit,
    onSort: (SortMode) -> Unit,
    onFilter: (EntryFilter) -> Unit,
    onAttributeKey: (String?) -> Unit,
    onAttributeValue: (String?) -> Unit,
    onSelect: (String) -> Unit,
    onVisible: (String) -> Unit,
    onAdd: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onRefresh: () -> Unit,
    onDismissMessage: () -> Unit
) {
    val criteria = state.criteria
    Column(modifier = Modifier.fillMaxSize().background(Lawn)) {
        Row(
            modifier = Modifier.fillMaxWidth().height(58.dp).background(Bark).padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "АЛЬМАНАХ ${criteria.category.title}",
                modifier = Modifier.weight(1f), color = Color.White,
                fontWeight = FontWeight.ExtraBold, fontSize = 19.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            IconButton(onClick = onRefresh, modifier = Modifier.size(40.dp)) {
                Icon(Icons.Default.Refresh, "Обновить каталог", tint = Color.White)
            }
            IconButton(onClick = onAdd, modifier = Modifier.size(40.dp).testTag("newEntry")) {
                Icon(Icons.Default.Add, "Добавить запись", tint = Golden)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Category.entries.forEach { category ->
                val caption = when (category) {
                    Category.PLANTS -> "🌱 Растения"
                    Category.ZOMBIES -> "🧟 Зомби"
                    Category.AREAS -> "🌎 Миры"
                }
                Surface(
                    modifier = Modifier.weight(1f).height(36.dp),
                    shape = RoundedCornerShape(10.dp),
                    color = if (criteria.category == category) Golden else Parchment,
                    border = BorderStroke(2.dp, Bark),
                    onClick = { onCategory(category) }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(caption, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            maxLines = 1, color = Ink)
                    }
                }
            }
        }

        OutlinedTextField(
            value = criteria.query, onValueChange = onQuery,
            placeholder = { Text("Поиск по названию...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = if (criteria.query.isNotBlank()) {
                { IconButton(onClick = { onQuery("") }) { Icon(Icons.Default.Close, "Очистить поиск") } }
            } else null,
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = CardCream,
                unfocusedContainerColor = CardCream,
                focusedBorderColor = Golden,
                unfocusedBorderColor = Bark
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp).height(55.dp)
                .testTag("catalogSearch")
        )

        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                .padding(horizontal = 10.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.spacedBy(7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val sorts = if (criteria.category == Category.PLANTS) SortMode.entries
                else SortMode.entries.filterNot { it == SortMode.COST_ASC || it == SortMode.COST_DESC }
            MenuPicker("↕ ${criteria.sort.label}", sorts, onSort) { it.label }
            MenuPicker("Фильтр: ${criteria.filter.label}", EntryFilter.entries, onFilter) { it.label }
            val keys = state.attributeOptions.keys.sorted()
            MenuPicker(
                "Поле: ${criteria.attributeKey?.let { translateKey(it) } ?: "Любое"}",
                listOf<String?>(null) + keys,
                onAttributeKey
            ) { it?.let(::translateKey) ?: "Любое" }
            if (criteria.attributeKey != null) {
                MenuPicker(
                    "Значение: ${criteria.attributeValue ?: "Любое"}",
                    listOf<String?>(null) + state.attributeOptions[criteria.attributeKey].orEmpty(),
                    onAttributeValue
                ) { it ?: "Любое" }
            }
        }

        if (state.message != null) {
            Row(
                modifier = Modifier.fillMaxWidth().background(Parchment).clickable(onClick = onDismissMessage)
                    .padding(horizontal = 12.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(state.message, modifier = Modifier.weight(1f), fontSize = 11.sp, color = Ink)
                Icon(Icons.Default.Close, contentDescription = "Закрыть сообщение", modifier = Modifier.size(16.dp))
            }
        }

        if (state.loading) {
            Row(modifier = Modifier.fillMaxWidth().height(3.dp), horizontalArrangement = Arrangement.Center) {
                androidx.compose.material3.LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth(), color = Golden, trackColor = Forest
                )
            }
        }

        BoxWithConstraints(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 9.dp, vertical = 5.dp)
                .border(4.dp, Bark, RoundedCornerShape(19.dp))
                .clip(RoundedCornerShape(19.dp))
                .background(Parchment)
        ) {
            val thumbnailWidth = if (maxWidth > 600.dp) 145.dp else 103.dp
            val selectedEntry = state.selected
            Row(Modifier.fillMaxSize()) {
                Column(Modifier.width(thumbnailWidth).fillMaxHeight().background(LightWood)) {
                    Box(
                        Modifier.fillMaxWidth().background(Bark).padding(4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("${state.items.size} / ${state.totalInCategory}",
                            fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
                    }
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(5.dp).testTag("catalogItems"),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        items(state.items, key = { it.id }) { entry ->
                            LaunchedEffect(entry.id, entry.detailsLoaded) {
                                if (!entry.detailsLoaded && !entry.isCustom) onVisible(entry.id)
                            }
                            Thumbnail(entry, entry.id == state.selected?.id,
                                onClick = { onSelect(entry.id) })
                        }
                    }
                }
                Box(Modifier.width(4.dp).fillMaxHeight().background(Bark))
                if (selectedEntry == null) {
                    Box(Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
                        Text("Ничего не найдено. Измените фильтры или добавьте запись.",
                            textAlign = TextAlign.Center, color = Ink)
                    }
                } else {
                    EntryDetails(
                        entry = selectedEntry,
                        onEdit = onEdit,
                        onDelete = onDelete,
                        onRetry = { onVisible(selectedEntry.id) },
                        modifier = Modifier.weight(1f).fillMaxHeight()
                    )
                }
            }
        }
    }
}

@Composable
private fun Thumbnail(entry: AlmanacEntry, selected: Boolean, onClick: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp))
            .background(if (selected) Golden else Parchment)
            .border(if (selected) 3.dp else 2.dp, if (selected) Golden else Bark, RoundedCornerShape(13.dp))
            .clickable(onClick = onClick)
            .padding(5.dp).testTag("entryRow-${entry.id}"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        EntityPicture(entry, Modifier.fillMaxWidth().height(78.dp).clip(RoundedCornerShape(9.dp)))
        Text(entry.name, fontSize = 10.sp, color = Ink, fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun EntityPicture(entry: AlmanacEntry, modifier: Modifier = Modifier) {
    val gradient = Brush.verticalGradient(listOf(Color(0xFF1A6374), Color(0xFF062B38)))
    Box(modifier.background(gradient), contentAlignment = Alignment.Center) {
        SubcomposeAsyncImage(
            model = entry.imageUrl,
            contentDescription = entry.name,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize(),
            loading = { FallbackPicture(entry.category) },
            error = { FallbackPicture(entry.category) },
            success = { SubcomposeAsyncImageContent() }
        )
    }
}

@Composable
private fun FallbackPicture(category: Category) {
    Text(when (category) {
        Category.PLANTS -> "🌻"
        Category.ZOMBIES -> "🧟"
        Category.AREAS -> "🌎"
    }, fontSize = 39.sp, textAlign = TextAlign.Center)
}

@Composable
private fun EntryDetails(
    entry: AlmanacEntry, onEdit: () -> Unit, onDelete: () -> Unit,
    onRetry: () -> Unit, modifier: Modifier = Modifier
) {
    val orderedFields = remember(entry.attributes) {
        val order = listOf("family", "sun cost", "recharge", "toughness", "speed", "stamina", "description")
        entry.attributes.entries.sortedWith(compareBy({ order.indexOf(it.key.lowercase()).let { idx -> if (idx == -1) 100 else idx } }, { it.key }))
    }
    LazyColumn(
        modifier = modifier.background(Parchment).padding(horizontal = 12.dp, vertical = 10.dp).testTag("entryDetail"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text(entry.name, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold,
                    color = Forest, textAlign = TextAlign.Center, lineHeight = 30.sp,
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
                if (entry.isCustom || entry.isEdited) {
                    Text(if (entry.isCustom) "Добавлено вами" else "Изменено локально",
                        color = Bark, fontSize = 11.sp)
                }
                Row(horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onEdit, modifier = Modifier.size(42.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Редактировать", tint = Forest)
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(42.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = if (entry.isCustom) "Удалить" else "Скрыть",
                            tint = Bark)
                    }
                }
            }
        }
        if (!entry.detailsLoaded) {
            item {
                Column(
                    modifier = Modifier.fillMaxWidth().background(CardCream, RoundedCornerShape(12.dp)).padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Характеристики запрашиваются из API. Если соединения нет, запись останется доступна в каталоге.",
                        fontSize = 12.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(6.dp))
                    Button(onClick = onRetry) { Text("Повторить загрузку") }
                }
            }
        } else if (orderedFields.isEmpty()) {
            item {
                Text("Характеристик пока нет. Их можно добавить через редактирование.",
                    modifier = Modifier.fillMaxWidth().background(CardCream, RoundedCornerShape(12.dp)).padding(14.dp),
                    fontSize = 13.sp, color = Ink)
            }
        } else {
            items(orderedFields, key = { it.key }) { field ->
                AttributeCard(translateKey(field.key), field.value)
            }
        }
        item {
            Text(
                if (entry.isCustom || entry.isEdited) "Данные сохранены только на этом устройстве"
                else "Источник: PvZ2 API · локальный кеш",
                fontSize = 10.sp, color = Bark,
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp), textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun AttributeCard(name: String, value: String) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp), color = CardCream
    ) {
        if (value.length > 70) {
            Column(Modifier.padding(horizontal = 12.dp, vertical = 13.dp)) {
                Text("$name:", fontWeight = FontWeight.Bold, color = Ink, fontSize = 14.sp)
                Spacer(Modifier.height(5.dp))
                Text(value, color = Ink, fontSize = 13.sp, lineHeight = 18.sp)
            }
        } else {
            Row(
                Modifier.padding(horizontal = 10.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("$name:", Modifier.weight(0.50f), fontWeight = FontWeight.Bold,
                    fontSize = 13.sp, color = Ink)
                Text(value, Modifier.weight(0.50f), fontSize = 13.sp,
                    textAlign = TextAlign.End, color = Ink)
            }
        }
    }
}

private fun translateKey(key: String): String = when (key.lowercase()) {
    "family" -> "Семейство"
    "sun cost" -> "Стоимость"
    "recharge" -> "Перезарядка"
    "toughness" -> "Прочность"
    "speed" -> "Скорость"
    "stamina" -> "Выносливость"
    "description" -> "Описание"
    "levels" -> "Уровни"
    "difficulty" -> "Сложность"
    "world" -> "Мир"
    else -> key.replaceFirstChar { it.uppercase() }
}

@Composable
private fun <T> MenuPicker(
    caption: String,
    options: List<T>,
    onSelect: (T) -> Unit,
    label: (T) -> String
) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        Surface(
            onClick = { expanded = true },
            shape = RoundedCornerShape(10.dp), color = Parchment,
            border = BorderStroke(1.5.dp, Bark)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 9.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(caption, fontWeight = FontWeight.Medium, fontSize = 11.sp, color = Ink)
                Icon(Icons.Default.ArrowDropDown, null, modifier = Modifier.size(18.dp))
            }
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false },
            modifier = Modifier.heightIn(max = 300.dp).background(CardCream)) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(label(option), fontSize = 13.sp) },
                    onClick = { expanded = false; onSelect(option) }
                )
            }
        }
    }
}
