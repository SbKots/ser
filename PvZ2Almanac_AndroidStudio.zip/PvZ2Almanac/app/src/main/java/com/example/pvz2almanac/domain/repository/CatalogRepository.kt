package com.example.pvz2almanac.domain.repository

import com.example.pvz2almanac.domain.model.AlmanacEntry
import kotlinx.coroutines.flow.Flow

interface CatalogRepository {
    fun observeEntries(): Flow<List<AlmanacEntry>>
    /** Мгновенно добавляет локальный список имен для первого запуска без интернета. */
    suspend fun prepareOfflineCatalog()
    /** Обновляет только списки имен с публичного API. Не затирает правки. */
    suspend fun refreshNames(): String?
    /** Загружает подробности по запросу и кеширует результат. */
    suspend fun loadDetailsIfNeeded(id: String)
    suspend fun save(entry: AlmanacEntry)
    /** Свои записи удаляет, стандартные скрывает локально. */
    suspend fun remove(id: String)
}
