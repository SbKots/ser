package com.example.pvz2almanac.presentation.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.pvz2almanac.domain.model.AlmanacEntry
import com.example.pvz2almanac.domain.model.CatalogCriteria
import com.example.pvz2almanac.domain.model.Category
import com.example.pvz2almanac.domain.model.EntryFilter
import com.example.pvz2almanac.domain.model.SortMode
import com.example.pvz2almanac.domain.repository.CatalogRepository
import com.example.pvz2almanac.domain.usecase.FilterAndSortEntries
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

data class AlmanacUiState(
    val criteria: CatalogCriteria = CatalogCriteria(),
    val items: List<AlmanacEntry> = emptyList(),
    val selected: AlmanacEntry? = null,
    val totalInCategory: Int = 0,
    val attributeOptions: Map<String, List<String>> = emptyMap(),
    val loading: Boolean = false,
    val message: String? = null
)

@HiltViewModel
class AlmanacViewModel @Inject constructor(
    private val repository: CatalogRepository,
    private val filterAndSort: FilterAndSortEntries
) : ViewModel() {
    private val criteria = MutableStateFlow(CatalogCriteria())
    private val loading = MutableStateFlow(false)
    private val message = MutableStateFlow<String?>(null)

    val state = combine(repository.observeEntries(), criteria, loading, message) { all, settings, isLoading, notice ->
        val visible = filterAndSort(all, settings)
        val selected = visible.firstOrNull { it.id == settings.selectedId } ?: visible.firstOrNull()
        val attrs = all.asSequence()
            .filter { it.category == settings.category && !it.isHidden }
            .flatMap { it.attributes.asSequence() }
            .groupBy({ it.key }, { it.value })
            .mapValues { (_, values) -> values.distinct().filter { it.isNotBlank() }.sorted() }
            .filterValues { it.isNotEmpty() }
        AlmanacUiState(
            criteria = settings,
            items = visible,
            selected = selected,
            totalInCategory = all.count { it.category == settings.category && !it.isHidden },
            attributeOptions = attrs,
            loading = isLoading,
            message = notice
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AlmanacUiState())

    init {
        viewModelScope.launch {
            loading.value = true
            try {
                repository.prepareOfflineCatalog()
                message.value = repository.refreshNames()
            } catch (e: Exception) {
                message.value = "Не удалось открыть локальный каталог: ${e.localizedMessage.orEmpty()}"
            } finally {
                loading.value = false
            }
        }
    }

    fun selectCategory(category: Category) {
        criteria.value = CatalogCriteria(category = category)
    }

    fun setSearch(query: String) {
        criteria.value = criteria.value.copy(query = query, selectedId = null)
    }

    fun setSort(mode: SortMode) {
        criteria.value = criteria.value.copy(sort = mode)
    }

    fun setFilter(filter: EntryFilter) {
        criteria.value = criteria.value.copy(filter = filter, selectedId = null)
    }

    fun setAttributeKey(key: String?) {
        criteria.value = criteria.value.copy(attributeKey = key, attributeValue = null, selectedId = null)
    }

    fun setAttributeValue(value: String?) {
        criteria.value = criteria.value.copy(attributeValue = value, selectedId = null)
    }

    fun selectItem(id: String) {
        criteria.value = criteria.value.copy(selectedId = id)
        requestDetails(id)
    }

    fun requestDetails(id: String) {
        viewModelScope.launch { repository.loadDetailsIfNeeded(id) }
    }

    fun refresh() {
        viewModelScope.launch {
            loading.value = true
            try {
                message.value = repository.refreshNames() ?: "Каталог обновлён"
            } catch (e: Exception) {
                message.value = "Ошибка обновления: ${e.localizedMessage.orEmpty()}"
            } finally {
                loading.value = false
            }
        }
    }

    fun saveEntry(
        original: AlmanacEntry?, name: String,
        imageUrl: String, attributes: Map<String, String>
    ) {
        if (name.isBlank()) {
            message.value = "Укажите название"
            return
        }
        viewModelScope.launch {
            val entry = if (original == null) {
                AlmanacEntry(
                    id = "local:${UUID.randomUUID()}",
                    category = criteria.value.category,
                    name = name.trim(),
                    imageUrl = imageUrl.trim().ifBlank { null },
                    attributes = attributes,
                    isCustom = true,
                    detailsLoaded = true
                )
            } else {
                original.copy(
                    name = name.trim(),
                    imageUrl = imageUrl.trim().ifBlank { null },
                    attributes = attributes,
                    isEdited = !original.isCustom,
                    detailsLoaded = true
                )
            }
            try {
                repository.save(entry)
                criteria.value = criteria.value.copy(selectedId = entry.id, filter = EntryFilter.ALL,
                    attributeKey = null, attributeValue = null, query = "")
                message.value = "Запись сохранена на устройстве"
            } catch (e: Exception) {
                message.value = "Ошибка сохранения: ${e.localizedMessage.orEmpty()}"
            }
        }
    }

    fun removeEntry(entry: AlmanacEntry) {
        viewModelScope.launch {
            try {
                repository.remove(entry.id)
                criteria.value = criteria.value.copy(selectedId = null)
                message.value = if (entry.isCustom) "Запись удалена" else "Запись скрыта локально"
            } catch (e: Exception) {
                message.value = "Не удалось удалить: ${e.localizedMessage.orEmpty()}"
            }
        }
    }

    fun clearMessage() { message.value = null }
}
