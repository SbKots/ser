package com.example.pvz2almanac.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [EntryEntity::class], version = 1, exportSchema = false)
abstract class AlmanacDatabase : RoomDatabase() {
    abstract fun entries(): EntryDao
}
