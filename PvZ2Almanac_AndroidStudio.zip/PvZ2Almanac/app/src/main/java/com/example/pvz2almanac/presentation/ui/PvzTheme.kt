package com.example.pvz2almanac.presentation.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Палитра по мотивам игрового альманаха на предоставленном скриншоте.
val Lawn = Color(0xFF3F6327)
val Forest = Color(0xFF21461D)
val Bark = Color(0xFF59351F)
val LightWood = Color(0xFF95653C)
val Parchment = Color(0xFFF1DFB7)
val CardCream = Color(0xFFF8EED7)
val Golden = Color(0xFFF6CB61)
val Ink = Color(0xFF302418)

private val colors = lightColorScheme(
    primary = Forest,
    onPrimary = Color.White,
    primaryContainer = Golden,
    onPrimaryContainer = Ink,
    background = Lawn,
    onBackground = Ink,
    surface = CardCream,
    onSurface = Ink,
    outline = LightWood
)

@Composable
fun PvzTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = colors, typography = Typography(), content = content)
}
