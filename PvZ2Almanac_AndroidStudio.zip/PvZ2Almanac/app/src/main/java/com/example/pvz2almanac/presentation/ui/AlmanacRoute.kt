package com.example.pvz2almanac.presentation.ui

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.pvz2almanac.domain.model.AlmanacEntry
import com.example.pvz2almanac.presentation.vm.AlmanacViewModel

/** Smart wrapper: только здесь UI знает о ViewModel. */
@Composable
fun AlmanacRoute(viewModel: AlmanacViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var editorOpen by remember { mutableStateOf(false) }
    var editingEntry by remember { mutableStateOf<AlmanacEntry?>(null) }
    var deleteRequest by remember { mutableStateOf<AlmanacEntry?>(null) }

    AlmanacScreen(
        state = state,
        onCategory = viewModel::selectCategory,
        onQuery = viewModel::setSearch,
        onSort = viewModel::setSort,
        onFilter = viewModel::setFilter,
        onAttributeKey = viewModel::setAttributeKey,
        onAttributeValue = viewModel::setAttributeValue,
        onSelect = viewModel::selectItem,
        onVisible = viewModel::requestDetails,
        onAdd = { editingEntry = null; editorOpen = true },
        onEdit = { editingEntry = state.selected; editorOpen = true },
        onDelete = { deleteRequest = state.selected },
        onRefresh = viewModel::refresh,
        onDismissMessage = viewModel::clearMessage
    )
    if (editorOpen) {
        EntryEditorDialog(
            category = state.criteria.category,
            original = editingEntry,
            onDismiss = { editorOpen = false },
            onSave = { name, imageUrl, fields ->
                viewModel.saveEntry(editingEntry, name, imageUrl, fields)
                editorOpen = false
            }
        )
    }
    deleteRequest?.let { entry ->
        AlertDialog(
            onDismissRequest = { deleteRequest = null },
            containerColor = Parchment,
            title = { Text(if (entry.isCustom) "Удалить запись?" else "Скрыть из альманаха?") },
            text = { Text(if (entry.isCustom) "Это действие удалит созданную вами запись."
                else "Запись останется в API, но будет скрыта в вашем локальном каталоге.") },
            confirmButton = {
                TextButton(onClick = { viewModel.removeEntry(entry); deleteRequest = null }) {
                    Text(if (entry.isCustom) "Удалить" else "Скрыть")
                }
            },
            dismissButton = { TextButton(onClick = { deleteRequest = null }) { Text("Отмена") } }
        )
    }
}
