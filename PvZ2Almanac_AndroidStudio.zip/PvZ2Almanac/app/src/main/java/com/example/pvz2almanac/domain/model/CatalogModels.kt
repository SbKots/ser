package com.example.pvz2almanac.domain.model

/** Domain не зависит от Android, Room, Retrofit или Compose. */
enum class Category(val apiPath: String, val title: String, val singular: String) {
    PLANTS("plants", "РАСТЕНИЙ", "Растение"),
    ZOMBIES("zombies", "ЗОМБИ", "Зомби"),
    AREAS("areas", "МИРОВ", "Мир")
}

data class AlmanacEntry(
    val id: String,
    val category: Category,
    val name: String,
    val imageUrl: String? = null,
    val attributes: Map<String, String> = emptyMap(),
    val isCustom: Boolean = false,
    val isEdited: Boolean = false,
    val detailsLoaded: Boolean = false,
    val isHidden: Boolean = false
)

enum class SortMode(val label: String) {
    NAME_ASC("Имя: А → Я"),
    NAME_DESC("Имя: Я → А"),
    COST_ASC("Солнца: по возрастанию"),
    COST_DESC("Солнца: по убыванию"),
    CUSTOM_FIRST("Свои сначала")
}

enum class EntryFilter(val label: String) {
    ALL("Все записи"),
    MY_ENTRIES("Добавленные мной"),
    EDITED("Отредактированные"),
    WITH_DETAILS("С характеристиками"),
    WITHOUT_DETAILS("Без характеристик")
}

data class CatalogCriteria(
    val category: Category = Category.PLANTS,
    val query: String = "",
    val sort: SortMode = SortMode.NAME_ASC,
    val filter: EntryFilter = EntryFilter.ALL,
    val attributeKey: String? = null,
    val attributeValue: String? = null,
    val selectedId: String? = null
)
