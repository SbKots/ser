package com.example.pvz2almanac.data.remote

import com.google.gson.JsonObject
import retrofit2.http.GET
import retrofit2.http.Path

/** API только для чтения: POST/PUT/PATCH публичный сервер не поддерживает. */
interface PvzApi {
    @GET("api/{kind}")
    suspend fun getNames(@Path("kind") kind: String): List<String>

    @GET("api/{kind}/{name}")
    suspend fun getDetails(
        @Path("kind") kind: String,
        @Path("name") name: String
    ): JsonObject
}
