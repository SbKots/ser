package com.example.pvz2almanac.data.di

import android.content.Context
import androidx.room.Room
import com.example.pvz2almanac.data.local.AlmanacDatabase
import com.example.pvz2almanac.data.local.EntryDao
import com.example.pvz2almanac.data.remote.PvzApi
import com.example.pvz2almanac.data.repository.CatalogRepositoryImpl
import com.example.pvz2almanac.domain.repository.CatalogRepository
import com.example.pvz2almanac.domain.usecase.FilterAndSortEntries
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryBindings {
    @Binds
    abstract fun bindCatalogRepository(impl: CatalogRepositoryImpl): CatalogRepository
}

@Module
@InstallIn(SingletonComponent::class)
object DataModule {
    @Provides
    fun provideFilterAndSort(): FilterAndSortEntries = FilterAndSortEntries()

    @Provides @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AlmanacDatabase =
        Room.databaseBuilder(context, AlmanacDatabase::class.java, "pvz2_catalog.db").build()

    @Provides
    fun provideDao(database: AlmanacDatabase): EntryDao = database.entries()

    @Provides @Singleton
    fun provideApi(): PvzApi = Retrofit.Builder()
        .baseUrl("https://pvz-2-api.vercel.app/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(PvzApi::class.java)
}
