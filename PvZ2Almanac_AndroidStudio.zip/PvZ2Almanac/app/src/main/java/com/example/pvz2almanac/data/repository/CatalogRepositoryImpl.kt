package com.example.pvz2almanac.data.repository

import android.content.Context
import com.example.pvz2almanac.data.local.EntryDao
import com.example.pvz2almanac.data.local.toDomain
import com.example.pvz2almanac.data.local.toEntity
import com.example.pvz2almanac.data.remote.PvzApi
import com.example.pvz2almanac.domain.model.AlmanacEntry
import com.example.pvz2almanac.domain.model.Category
import com.example.pvz2almanac.domain.repository.CatalogRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CatalogRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val api: PvzApi,
    private val dao: EntryDao
) : CatalogRepository {
    private val loadingIds = ConcurrentHashMap.newKeySet<String>()

    override fun observeEntries(): Flow<List<AlmanacEntry>> =
        dao.observe().map { list -> list.map { it.toDomain() } }

    override suspend fun prepareOfflineCatalog() {
        val data = context.assets.open("catalog_names.json").bufferedReader().use { it.readText() }
        val root = JSONObject(data)
        for (category in Category.entries) {
            val array = root.getJSONArray(category.apiPath)
            val entries = (0 until array.length()).map { index ->
                remoteEntry(category, array.getString(index)).toEntity()
            }
            dao.insertMissing(entries)
        }
    }

    override suspend fun refreshNames(): String? {
        var errors = 0
        Category.entries.forEach { category ->
            try {
                val names = api.getNames(category.apiPath)
                dao.insertMissing(names.map { remoteEntry(category, it).toEntity() })
            } catch (ex: Exception) {
                // Каталог остается доступным из Room и локального JSON.
                errors++
            }
        }
        return if (errors > 0) "Часть данных не обновлена: работаем с локальным каталогом" else null
    }

    override suspend fun loadDetailsIfNeeded(id: String) {
        if (!loadingIds.add(id)) return
        try {
            val cached = dao.find(id) ?: return
            if (cached.detailsLoaded || cached.isCustom || cached.isEdited || cached.isHidden) return
            val entry = cached.toDomain()
            val raw = api.getDetails(entry.category.apiPath, entry.name.lowercase())
            val fields = linkedMapOf<String, String>()
            raw.entrySet().forEach { (key, value) ->
                if (!key.equals("name", true) && !key.equals("image", true) && !value.isJsonNull) {
                    fields[key] = if (value.isJsonPrimitive) value.asString else value.toString()
                }
            }
            val relative = raw.get("image")?.takeIf { !it.isJsonNull }?.asString
            val image = when {
                relative.isNullOrBlank() -> null
                relative.startsWith("http://") || relative.startsWith("https://") -> relative
                else -> "https://pvz-2-api.vercel.app/${relative.trimStart('/')}"
            }
            // При одновременном редактировании не затираем пользовательские изменения.
            val latest = dao.find(id) ?: return
            if (!latest.isEdited && !latest.isCustom && !latest.isHidden) {
                dao.save(latest.toDomain().copy(imageUrl = image, attributes = fields, detailsLoaded = true).toEntity())
            }
        } catch (_: Exception) {
            // Сеть может быть отключена или отдельная карточка отсутствует в API.
            // Такой элемент останется в каталоге; загрузку можно повторить при открытии.
        } finally {
            loadingIds.remove(id)
        }
    }

    override suspend fun save(entry: AlmanacEntry) {
        dao.save(entry.toEntity())
    }

    override suspend fun remove(id: String) {
        val entity = dao.find(id) ?: return
        if (entity.isCustom) dao.delete(id) else dao.hide(id)
    }

    private fun remoteEntry(category: Category, name: String) = AlmanacEntry(
        id = "${category.apiPath}:${name.lowercase()}", category = category,
        name = name.replaceFirstChar { it.uppercase() }
    )
}
