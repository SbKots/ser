package com.example.pvz2almanac.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.pvz2almanac.domain.model.AlmanacEntry
import com.example.pvz2almanac.domain.model.Category
import org.json.JSONObject

@Entity(tableName = "entries")
data class EntryEntity(
    @PrimaryKey val id: String,
    val category: String,
    val name: String,
    val imageUrl: String?,
    val attributesJson: String,
    val isCustom: Boolean,
    val isEdited: Boolean,
    val detailsLoaded: Boolean,
    val isHidden: Boolean
)

internal fun EntryEntity.toDomain(): AlmanacEntry {
    val json = runCatching { JSONObject(attributesJson) }.getOrDefault(JSONObject())
    val fields = buildMap {
        for (key in json.keys()) put(key, json.optString(key))
    }
    return AlmanacEntry(
        id, Category.valueOf(category), name, imageUrl, fields,
        isCustom, isEdited, detailsLoaded, isHidden
    )
}

internal fun AlmanacEntry.toEntity() = EntryEntity(
    id = id, category = category.name, name = name, imageUrl = imageUrl,
    attributesJson = JSONObject(attributes).toString(), isCustom = isCustom,
    isEdited = isEdited, detailsLoaded = detailsLoaded, isHidden = isHidden
)
