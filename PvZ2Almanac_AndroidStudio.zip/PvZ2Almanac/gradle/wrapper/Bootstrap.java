package org.gradle.wrapper;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Small reproducible wrapper launcher included because the official Gradle wrapper
 * binary cannot be redistributed from this build environment. Its source is shipped.
 * It uses HTTPS and SHA-256 pinning from gradle-wrapper.properties.
 */
class GradleWrapperMain {
    public static void main(String[] args) throws Exception {
        Path project = Paths.get(System.getProperty("user.dir"));
        Properties properties = new Properties();
        try (InputStream in = Files.newInputStream(project.resolve("gradle/wrapper/gradle-wrapper.properties"))) {
            properties.load(in);
        }
        String url = properties.getProperty("distributionUrl");
        String sha256 = properties.getProperty("distributionSha256Sum");
        String name = url.substring(url.lastIndexOf('/') + 1).replace("-bin.zip", "");
        Path cache = Paths.get(System.getProperty("user.home"), ".gradle", "wrapper", "dists", "pvz2-bootstrap", name);
        Path home = cache.resolve(name);
        boolean windows = System.getProperty("os.name").toLowerCase().contains("win");
        Path executable = home.resolve("bin").resolve(windows ? "gradle.bat" : "gradle");
        if (!Files.isRegularFile(executable)) {
            Files.createDirectories(cache);
            Path zip = cache.resolve(name + "-bin.zip");
            System.out.println("Downloading verified Gradle distribution from " + url);
            HttpClient http = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.ALWAYS).build();
            HttpRequest request = HttpRequest.newBuilder(URI.create(url)).GET().build();
            HttpResponse<InputStream> response = http.send(request, HttpResponse.BodyHandlers.ofInputStream());
            if (response.statusCode() != 200) throw new IllegalStateException("Gradle HTTP " + response.statusCode());
            try (InputStream in = response.body()) { Files.copy(in, zip, java.nio.file.StandardCopyOption.REPLACE_EXISTING); }
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            try (InputStream in = Files.newInputStream(zip)) {
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) != -1) digest.update(buffer, 0, n);
            }
            StringBuilder got = new StringBuilder();
            for (byte value : digest.digest()) got.append(String.format("%02x", value & 0xff));
            if (!got.toString().equalsIgnoreCase(sha256)) {
                Files.deleteIfExists(zip);
                throw new SecurityException("Gradle ZIP SHA-256 mismatch");
            }
            try (ZipInputStream input = new ZipInputStream(Files.newInputStream(zip))) {
                ZipEntry entry;
                while ((entry = input.getNextEntry()) != null) {
                    Path target = cache.resolve(entry.getName()).normalize();
                    if (!target.startsWith(cache)) throw new SecurityException("Unsafe path in Gradle ZIP");
                    if (entry.isDirectory()) Files.createDirectories(target);
                    else {
                        Files.createDirectories(target.getParent());
                        try (OutputStream out = Files.newOutputStream(target)) { input.transferTo(out); }
                    }
                    input.closeEntry();
                }
            }
            Files.deleteIfExists(zip);
        }
        if (!windows) executable.toFile().setExecutable(true);
        List<String> command = new ArrayList<>();
        command.add(executable.toAbsolutePath().toString());
        command.addAll(Arrays.asList(args));
        Process process = new ProcessBuilder(command).directory(project.toFile()).inheritIO().start();
        System.exit(process.waitFor());
    }
}
